This .zip file includes:
- the formal version of TR-548 v3.0 for delivery (.pdf)
- the master TR-548 v3.0 (word)
- a diff between TR-548 v2.0 and v3.0