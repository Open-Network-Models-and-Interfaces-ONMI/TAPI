The .zip file provides the formal version of TR-548 V1.1.

The .pdf file is for publication. The .docx file is a basis for the next release of TR-548.